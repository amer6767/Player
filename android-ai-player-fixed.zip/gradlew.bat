@echo off
REM Minimal gradlew shim - use system gradle if available
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle %*
) else (
  echo No gradle found
)
