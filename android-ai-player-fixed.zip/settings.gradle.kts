rootProject.name = "android-ai-player-fixed"
include(":app")
