package com.aitr.data

import android.content.Context
import android.util.Log
import java.io.File

class DataCollector(private val ctx: Context) {
    private val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir

    fun saveFrame(sessionId:String, bytes:ByteArray, ts:Long): String {
        val d = File(base, "sessions/$sessionId"); d.mkdirs()
        val name = "frame_%d.jpg".format(ts)
        File(d, name).writeBytes(bytes)
        Log.i("DataCollector","saved $name")
        return "sessions/$sessionId/$name"
    }
}
