package com.aitr.store

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Database

@Database(entities=[Experience::class], version=1)
abstract class AppDatabase: RoomDatabase() {
    abstract fun experienceDao(): ExperienceDao
    companion object {
        @Volatile private var INST: AppDatabase? = null
        fun getInstance(ctx: Context): AppDatabase {
            return INST ?: synchronized(this) {
                val inst = Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "ai_tr_db").build()
                INST = inst
                inst
            }
        }
    }
}
