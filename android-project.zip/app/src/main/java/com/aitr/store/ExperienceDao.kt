package com.aitr.store

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ExperienceDao {
    @Insert fun insert(exp: Experience)
    @Query("SELECT * FROM experience ORDER BY timestamp DESC LIMIT :n") fun recent(n:Int): List<Experience>
}
