package com.aitr

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.util.Log
import java.io.File
import java.util.zip.ZipFile
import com.aitr.service.CaptureService
import com.aitr.ml.ModelManager

class MainActivity : AppCompatActivity() {
    private val REQ_MEDIA = 4242
    private lateinit var tvStatus: TextView
    private lateinit var modelManager: ModelManager
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tv_status)
        modelManager = ModelManager(this)

        findViewById<Button>(R.id.btn_extract).setOnClickListener { findAndExtractTRM() }
        findViewById<Button>(R.id.btn_capture).setOnClickListener { requestProjection() }
        findViewById<Button>(R.id.btn_record).setOnClickListener { startRecordingSession() }
        findViewById<Button>(R.id.btn_stop).setOnClickListener { stopRecording() }
        findViewById<Button>(R.id.btn_train).setOnClickListener { tvStatus.text = "Training (light) - placeholder" }
        findViewById<Button>(R.id.btn_ai).setOnClickListener { startAIMode() }
    }

    private fun requestProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_MEDIA)
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode==REQ_MEDIA && resultCode==Activity.RESULT_OK && data!=null) {
            val svc = Intent(this, CaptureService::class.java)
            svc.putExtra("media_intent", data)
            svc.putExtra("session_id", "session_auto")
            startForegroundService(svc)
            tvStatus.text = "Recording session (foreground)"
        }
    }

    private fun findAndExtractTRM() {
        try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val zip = File(downloads, "TinyRecursiveModels-main.zip")
            if (!zip.exists()) { tvStatus.text = "TinyRecursiveModels-main.zip not found in Downloads"; return }
            ZipFile(zip).use { zf ->
                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    if (e.name.endsWith(".tflite")) {
                        val out = File(filesDir, "player_model.tflite")
                        zf.getInputStream(e).use { inp -> out.outputStream().use { outp -> inp.copyTo(outp) } }
                        tvStatus.text = "Extracted ${e.name}"
                        modelManager.loadModelFromFile(out.absolutePath)
                        return
                    }
                }
            }
            tvStatus.text = "No .tflite found in zip"
        } catch (ex:Exception) {
            Log.e(TAG, "extract", ex); tvStatus.text = "Extraction error"
        }
    }

    private fun startRecordingSession() {
        // Starts CaptureService if not already started (media projection must be granted first)
        tvStatus.text = "Recording started (frames + touches)"
        startService(Intent(this, CaptureService::class.java))
    }

    private fun stopRecording() {
        stopService(Intent(this, CaptureService::class.java))
        tvStatus.text = "Recording stopped"
    }

    private fun startAIMode() {
        modelManager.ensureModelLoaded()
        val svc = Intent(this, CaptureService::class.java)
        svc.putExtra("start_ai", true)
        startForegroundService(svc)
        tvStatus.text = "AI mode running"
    }
}
