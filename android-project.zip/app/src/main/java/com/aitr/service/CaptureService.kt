package com.aitr.service

import android.app.Service
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.content.Intent
import android.graphics.Bitmap
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.aitr.data.DataCollector
import com.aitr.ml.ModelManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

class CaptureService : Service() {
    private val TAG = "CaptureService"
    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var handler: Handler? = null
    private lateinit var collector: DataCollector
    private lateinit var modelManager: ModelManager
    private var frameCount = 0
    private val inferenceEvery = 3

    override fun onCreate() {
        super.onCreate()
        startForeground(1, createNotification("AI TR"))
        val ht = HandlerThread("cap"); ht.start(); handler = Handler(ht.looper)
        collector = DataCollector(this)
        modelManager = ModelManager(this)
    }

    private fun createNotification(text:String): Notification {
        val channelId = "ai_tr"
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channelId, "AI TR", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, channelId).setContentTitle("AI TR").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            val mi = it.getParcelableExtra<Intent>("media_intent")
            if (mi != null) {
                val mpm = getSystemService(MediaProjectionManager::class.java)
                projection = mpm.getMediaProjection(RESULT_OK, mi as Intent)
                setupReader()
            }
            if (it.getBooleanExtra("start_ai", false)) {
                modelManager.loadModelFromAssetsOrFile()
            }
        }
        return START_STICKY
    }

    private fun setupReader() {
        val width = 1280; val height = 720
        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        projection?.createVirtualDisplay("ai-cap", width, height, resources.displayMetrics.densityDpi, 0, imageReader?.surface, null, handler)
        imageReader?.setOnImageAvailableListener({ reader ->
            val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            frameCount++
            val bytes = imageToJpeg(img)
            img.close()
            if (bytes != null) {
                val ts = System.currentTimeMillis()
                CoroutineScope(Dispatchers.IO).launch { collector.saveFrame("session_auto", bytes, ts) }
                if (frameCount % inferenceEvery == 0) { modelManager.tickInference(bytes) }
            }
        }, handler)
    }

    private fun imageToJpeg(image: Image): ByteArray? {
        return try {
            val plane = image.planes[0]; val buffer = plane.buffer
            val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val baos = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos); baos.toByteArray()
        } catch (e:Exception) { Log.e(TAG, "imageToJpeg", e); null }
    }

    override fun onDestroy() { imageReader?.close(); projection?.stop(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
