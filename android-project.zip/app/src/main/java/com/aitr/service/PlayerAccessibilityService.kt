package com.aitr.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

class PlayerAccessibilityService: AccessibilityService() {
    private val q = LinkedBlockingQueue<GestureDescription>(4)
    override fun onServiceConnected() {
        thread(start=true) {
            while(true) {
                val g = q.take()
                dispatchGesture(g, object: GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) { Log.i("PlayerAcc","done") }
                    override fun onCancelled(gestureDescription: GestureDescription?) { Log.i("PlayerAcc","cancel") }
                }, null)
                Thread.sleep(60)
            }
        }
    }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}
    fun tap(x:Int,y:Int,dur:Long=30) {
        val p = Path(); p.moveTo(x.toFloat(), y.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,dur)).build()
        q.offer(g)
    }
    fun swipe(x1:Int,y1:Int,x2:Int,y2:Int,dur:Long=250) {
        val p = Path(); p.moveTo(x1.toFloat(), y1.toFloat()); p.lineTo(x2.toFloat(), y2.toFloat())
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,dur)).build()
        q.offer(g)
    }
}
