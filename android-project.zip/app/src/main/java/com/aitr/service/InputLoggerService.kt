package com.aitr.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class InputLoggerService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); Log.i("InputLogger","started") }
    override fun onDestroy() { super.onDestroy(); Log.i("InputLogger","stopped") }
}
