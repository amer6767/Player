package com.aitr.train

import android.util.Log

object LocalTrainer {
    fun trainFromSession(path:String) {
        // placeholder - implement small logistic/regression trainer or upload for server training
        Log.i("LocalTrainer","Would train from session: $path (placeholder)")
    }
}
