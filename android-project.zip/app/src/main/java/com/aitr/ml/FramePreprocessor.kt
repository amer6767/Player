package com.aitr.ml

import android.graphics.Bitmap
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque

class FramePreprocessor {
    private val TAG = "FramePreprocessor"
    private val stackSize = 4
    private val targetW = 128
    private val targetH = 128
    private val buffer = ArrayDeque<Bitmap>()

    fun reset() { buffer.clear() }

    fun pushFrame(bmp: Bitmap) {
        val resized = Bitmap.createScaledBitmap(bmp, targetW, targetH, true)
        if (buffer.size >= stackSize) buffer.removeFirst()
        buffer.addLast(resized)
    }

    fun hasStack(): Boolean = buffer.size == stackSize

    fun getStackAsByteBuffer(): ByteBuffer? {
        if (!hasStack()) { Log.w(TAG, "Not enough frames"); return null }
        val floats = FloatArray(targetW * targetH * 3 * stackSize)
        var idx = 0
        for (bmp in buffer) {
            val pixels = IntArray(targetW * targetH)
            bmp.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH)
            for (p in pixels) {
                val r = ((p shr 16) and 0xFF) / 255.0f
                val g = ((p shr 8) and 0xFF) / 255.0f
                val b = (p and 0xFF) / 255.0f
                floats[idx++] = r; floats[idx++] = g; floats[idx++] = b
            }
        }
        val bb = ByteBuffer.allocateDirect(floats.size * 4).order(ByteOrder.nativeOrder())
        for (f in floats) bb.putFloat(f)
        bb.rewind()
        return bb
    }
}
