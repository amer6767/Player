package com.aitr.ml

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteBuffer

class TFLiteRunner(private val ctx: Context) {
    private var interpreter: Interpreter? = null
    private val TAG = "TFLiteRunner"

    fun loadModelFromAssets(name: String) {
        try {
            val afd = ctx.assets.openFd(name)
            val stream = FileInputStream(afd.fileDescriptor)
            val channel = stream.channel
            val mapped: MappedByteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.length)
            interpreter = Interpreter(mapped)
            Log.i(TAG, "Loaded model from assets")
        } catch (e: Exception) { Log.e(TAG, "load assets failed", e) }
    }

    fun loadModelFromPath(path: String) {
        try {
            val f = File(path)
            val stream = FileInputStream(f)
            val channel = stream.channel
            val mapped: MappedByteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, f.length())
            interpreter = Interpreter(mapped)
            Log.i(TAG, "Loaded model from path $path")
        } catch (e: Exception) { Log.e(TAG, "load path failed", e) }
    }

    fun run(inputBuffer: ByteBuffer): FloatArray? {
        if (interpreter == null) { Log.w(TAG, "Interpreter null"); return null }
        val out = Array(1) { FloatArray(10) } // 10 actions default
        interpreter!!.run(inputBuffer, out)
        return out[0]
    }
}
