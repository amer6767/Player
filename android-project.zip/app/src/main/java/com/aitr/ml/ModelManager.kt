package com.aitr.ml

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Log
import java.io.InputStreamReader

class ModelManager(private val ctx: Context) {
    private val TAG = "ModelManager"
    private val runner = TFLiteRunner(ctx)
    private val pre = FramePreprocessor()

    fun loadModelFromAssetsOrFile() {
        // try app files first
        val f = ctx.getFileStreamPath("player_model.tflite")
        if (f.exists()) { runner.loadModelFromPath(f.absolutePath); return }
        try { runner.loadModelFromAssets("player_model.tflite") } catch (e:Exception){ Log.i(TAG,"no asset model") }
    }

    fun loadModelFromFile(path: String) { runner.loadModelFromPath(path) }

    fun tickInference(jpegBytes: ByteArray) {
        try {
            val bmp = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size) ?: return
            pre.pushFrame(bmp)
            if (!pre.hasStack()) return
            val input = pre.getStackAsByteBuffer() ?: return
            val out = runner.run(input) ?: return
            var best = 0; var bv = out[0]
            for (i in out.indices) if (out[i] > bv) { best = i; bv = out[i] }
            Log.i(TAG, "Predicted action=$best conf=$bv")
            // TODO: map to gestures and execute via AccessibilityService
        } catch (e:Exception) { Log.e(TAG, "tickInference", e) }
    }
}
