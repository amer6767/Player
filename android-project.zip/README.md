# AI TR
Android AI Player (screen-capture based). Replace assets/player_model.tflite with your TRM model.
