rootProject.name = "ai-tr"
include(":app")
