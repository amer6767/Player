
Android AI Player - Complete Kotlin skeleton
- MediaProjection capture service
- AccessibilityService for touch injection
- DataCollector + Room experience replay memory
- TFLite runner placeholder (load model from assets)
- GitHub Actions workflow to build APK
How to build:
- Upload to GitHub and run Actions, or run locally with ./gradlew assembleDebug
Note: Replace placeholder model (assets/player_model.tflite) with a real TFLite file after training.
