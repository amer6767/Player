rootProject.name = "android-ai-player-complete"
include(":app")
