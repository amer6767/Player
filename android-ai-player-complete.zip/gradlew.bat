@echo off
gradlew %*
