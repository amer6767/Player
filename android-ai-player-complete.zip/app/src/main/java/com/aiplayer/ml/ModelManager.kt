package com.aiplayer.ml

import android.content.Context
import com.google.gson.Gson
import java.io.InputStreamReader

class ModelManager(private val ctx: Context) {
    private val runner = TFLiteRunner(ctx)
    private val actions = loadActions()

    private fun loadActions(): Map<String,Any> {
        val isr = InputStreamReader(ctx.assets.open("actions_config.json"))
        return Gson().fromJson(isr, Map::class.java) as Map<String,Any>
    }

    fun loadModel() { runner.loadModelFromAssets("player_model.tflite") }
    fun predictAndAct(input: Any) { /* placeholder: run inference and map to actions */ }
}
